export declare class TTMLController {
    /**
     * Constructor.
     */
    constructor();
    /**
     * Initialize.
     * @param mediaPlayer the dash.js player
     */
    init(mediaPlayer: any): void;
    private onTTMLPreProcess;
}
