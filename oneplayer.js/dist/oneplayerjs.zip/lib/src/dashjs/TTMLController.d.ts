export declare class TTMLController {
    /**
     * Initialize.
     * @param mediaPlayer the dash.js player
     */
    init(mediaPlayer: any): void;
    private onTTMLPreProcess;
}
